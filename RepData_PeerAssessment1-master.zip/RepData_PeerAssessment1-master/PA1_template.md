---
title: "Reproducible Research: Peer Assessment 1"

output: 
  html_document:
    keep_md: true

---
###Author: *Irina White*

## Loading and preprocessing the data

```r
myd<-unzip(zipfile='activity.zip', files='activity.csv')
mydata<-read.csv(myd,header = TRUE)
mydata$date<-as.Date(mydata$date)
```

## What is mean total number of steps taken per day?

1. Histogram of the total number of steps taken each day (omit NA values)


```r
mydata.complete<-mydata[complete.cases(mydata),]
dta.sum <- aggregate(x=mydata.complete['steps'], sum, by=list(mydata.complete$date))
hist(dta.sum$steps, main=('Daily Steps'), xlab='', col='cornflowerblue', cex.axis=0.8)
```

![](PA1_template_files/figure-html/unnamed-chunk-2-1.png)<!-- -->

2. **Mean** and **median** total number of steps taken per day

```r
mean(dta.sum$steps)
```

```
## [1] 10766.19
```

```r
median(dta.sum$steps)
```

```
## [1] 10765
```


## What is the average daily activity pattern?
1. Time series plot of the 5-minute interval (x-axis) and the average number of steps taken, averaged across all days (y-axis).

```r
mean.interval <- aggregate(x=mydata.complete['steps'], mean, by=list(mydata.complete$interval))
plot(mean.interval$steps~mean.interval$Group.1, type='l', col='red', lwd=2,
     xlab='Intervals', 
     ylab='Average # of Steps', 
     main='Average number of Steps by Intervals', cex.axis=0.8)
```

![](PA1_template_files/figure-html/unnamed-chunk-4-1.png)<!-- -->

2. The 5-minute interval, on average across all the days in the dataset, that contains the maximum number of steps:

```r
colnames(mean.interval)[1]<-'Interval'
mean.interval[mean.interval$steps==max(mean.interval$steps),]
```

```
##     Interval    steps
## 104      835 206.1698
```


## Imputing missing values
1. Calculate and report the total number of missing values in the dataset 
(i.e. the total number of rows with `NA`s)


```r
dim(mydata)[1]-dim(mydata.complete)[1]
```

```
## [1] 2304
```

2. Devise a strategy for filling in all of the missing values in the dataset. The strategy does not need to be sophisticated. For example, you could use the mean/median for that day, or the mean for that 5-minute interval, etc.


Use the average number of steps identified for the specific interval.


3. Create a new dataset that is equal to the original dataset but with the missing data filled in.

New dataset is mydata.replaced


```r
mydata.replaced<-mydata
for (i in 1:nrow(mydata)){
      if (is.na(mydata$steps[i])) {
            interval<-mydata$interval[i]
            mydata.replaced$steps[i]<-(mean.interval[mean.interval$Interval==interval,])$steps
      }
}
```


4. Make a histogram of the total number of steps taken each day and Calculate and report the **mean** and **median** total number of steps taken per day. Do these values differ from the estimates from the first part of the assignment? What is the impact of imputing missing data on the estimates of the total daily number of steps?


```r
dta.new.sum <- aggregate(x=mydata.replaced['steps'], sum, by=list(mydata.replaced$date))
hist(dta.new.sum$steps, main=('Daily Steps (Imputed)'), xlab='', col='green', cex.axis=0.8)
```

![](PA1_template_files/figure-html/unnamed-chunk-8-1.png)<!-- -->

```r
mean(dta.new.sum$steps)
```

```
## [1] 10766.19
```

```r
median(dta.new.sum$steps)
```

```
## [1] 10766.19
```

## Are there differences in activity patterns between weekdays and weekends?

1. Create a new factor variable in the dataset with two levels -- "weekday" and "weekend" indicating whether a given date is a weekday or weekend day.

```r
days<-weekdays(mydata.replaced$date)
for (k in 1:length(days)){
      if (days[k]=='Saturday'| days[k]=='Sunday'){
            days[k]<-'weekend'
            } else {
                  days[k]<-'weekday'
                  }
}
mydata.replaced<-cbind(mydata.replaced, days=as.factor(days))
head(mydata.replaced)
```

```
##       steps       date interval    days
## 1 1.7169811 2012-10-01        0 weekday
## 2 0.3396226 2012-10-01        5 weekday
## 3 0.1320755 2012-10-01       10 weekday
## 4 0.1509434 2012-10-01       15 weekday
## 5 0.0754717 2012-10-01       20 weekday
## 6 2.0943396 2012-10-01       25 weekday
```

2. Make a panel plot containing a time series plot (i.e. `type = "l"`) of the 5-minute interval (x-axis) and the average number of steps taken, averaged across all weekday days or weekend days (y-axis).


```r
#load ggplot library
library(ggplot2)

#create data frame averaged by invterval with type of days
mean.interval.day <- aggregate(steps~interval+days, mydata.replaced, mean)

#plot the data
p<-ggplot(mean.interval.day, aes(interval, steps))+
      geom_line(stat='identity', aes(col=days), show.legend = FALSE)+
      facet_wrap(days~., strip.position="top", ncol=1)+
      theme(strip.background = element_rect(fill="lightpink"))+
      theme(panel.background = element_rect(fill='white'))+
      ggtitle("Average # of Steps Per Interval by Day Type")
p      
```

![](PA1_template_files/figure-html/unnamed-chunk-10-1.png)<!-- -->


